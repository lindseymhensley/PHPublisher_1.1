INSERT INTO `php_users` ( `user_id` , `username` , `user_email` , `user_website` , `user_regdate` , `user_icq` , `user_occ` , `user_from` , `user_interests` , `user_aim` , `user_yim` , `user_msnm` , `user_password` , `newsletter` , `user_security_question` , `user_security_answer`, `user_theme`, `root_admin`, `user_level`) 
VALUES (
'',
'YOUR USERNAME GOES HERE', 
'YOUR EMAIL GOES HERE', 
'', 
'DATE YOU REGISTERED GOES HERE', 
'', 
'', 
'', 
'', 
'', 
'', 
'', 
'8f586fa42817420fff14bb3acc3823a255fc5ada', 
'1', 
'YOUR SECURITY QUESTION GOES HERE', 
'YOUR SECURITY ANSWER GOES HERE', 
'PHPublisher', 
'1', 
'99');
									