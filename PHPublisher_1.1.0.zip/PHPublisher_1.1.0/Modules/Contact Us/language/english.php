<?php
define("_ERROR_MSG_NOT_SENT", "There was an error while trying to send your message. <br />Your message was unable to be sent.");
define("_MSG_SENT", "Thank you, your message has been submitted. We will review your message and give you a reply within 3 days.");
define("_NAME", "Name");
define("_EMAIL", "E-Mail");
define("_SUBJECT", "Subject");
define("_MESSAGE", "Message");
define("_MISSING_NAME", "You forgot to disclose your name, please press back and try again.");
define("_MISSING_EMAIL", "You forgot to disclose your email, please press back and try again.");
define("_MISSING_MESSAGE", "You forgot to disclose your message, please press back and try again.");
define("_IP_ADDR", "IP Address:");
define("_CONTACT_US", "Admin Contact Form");
define("_DONT_SPAM", "Spamming, flooding, or any other kind of abuse towards the admin contact form will <strong>not</strong> be tolerated.");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
?>