<?php
define("_USERNAME", "Username");
define("_TAG", "Tag");
define("_MUST_LOG_IN", "You must be logged in to post.");
define("_CHAT_LOG", "Chat History");
define("_NO_TAG", "There are currently no tags.");
define("_PAGE", "Page");
define("_DELETE", "Delete");
define("_DELETE_ALL_TAGS", "Delete all tags");
define("_R_U_SURE", "Are you sure you wish to delete all of the Hotbox posts?");
define("_YES", "Yes");
define("_NO", "No");
define("_SUCCESS_PRUNE", "Successfully deleted all posts.");
define("_USERNAME_IN_USE", "<strong>Username taken!</strong>");
define("_ILLEGAL_NAME", "<strong>Illegal username!</strong>");
?>