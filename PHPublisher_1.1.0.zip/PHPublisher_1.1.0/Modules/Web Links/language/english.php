<?php

define("_NO_WEBLINKS", "We do not have any downloads available in this category currently.");
define("_TITLE", "Title");
define("_DESCRIPTION", "Description");
define("_NO_RESULTS", "Your search returned no results.");
define("_VIEWS", "Views");
define("_ADDED_ON", "Added on");
define("_VISIT", "Visit");
define("_BROWSE_BY_CATEGORY", "Browse by Category");
define("_AVAILABLE_WEBLINKS", "Available Web Links");
define("_WEBLINK_PAGE", "Page");
define("_AUTHOR", "Submitted by");
define("_ADD_WEBLINK", "Add Web Link");
define("_MISSING_ADDLINK_FIELDS", "There was an error in your form, please press back and try again.");
define("_ONLY_REGISTERED_USERS_MAY_SEND_LINKS", "<strong>You must be <a href=\"index.php?find=Members&file=Login\">logged in</a> to use this feature</strong>");
define("_LINK_SUBMITTED", "Your link has been submitted, please allow 24/48 hours for review.");
define("_LINK", "Link");
define("_DESC", "Description");
define("_RANK", "#");
define("_GO_BACK", "Go Back");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");

?>