<?php
define("_BROWSERS", "Browsers");
define("_MSIE", "MSIE");
define("_FF", "FireFox");
define("_NS", "Netscape");
define("_OPERA", "Opera");
define("_BOTS", "Search Engines");
define("_OTHER", "Other");
define("_OS", "Operating Systems");
define("_WIN", "Windows");
define("_LINUX", "Linux");
define("_MAC", "Mac/PPC");
define("_MISC", "Miscellaneous");
define("_TOTAL_ARTICLES", "Articles published");
define("_TOTAL_COMMENTS", "Comments posted");
define("_TOTAL_MEMBERS", "Registered users");
define("_VERSION", "PHPublisher version");
define("_TOTAL_HITS", "Total site page views");
define("_WE_HAVE_HAD", "We have had a total of");
define("_PAGE_VIEWS", "page views since");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
?>
