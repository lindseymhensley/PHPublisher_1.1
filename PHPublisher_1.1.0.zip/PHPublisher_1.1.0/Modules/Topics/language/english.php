<?php
define("_NONE", "<font color=\"#ff0000\">[X]</font>");
?>