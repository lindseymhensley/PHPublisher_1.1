<?php
header("Location: ".$base_url."/index.php?find=Profile&user_id=".$user->id());
die();
?>