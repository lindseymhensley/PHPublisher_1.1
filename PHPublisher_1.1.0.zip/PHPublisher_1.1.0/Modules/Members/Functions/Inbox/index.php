<?php
header("Location: ".$base_url."/index.php?find=Private Messages");
die();
?>
