<?php

///////////////////////////////////////////////////////////////
//	PHPublisher: A Dynamic Content Publishing System     //
//      ------------------------------------------------     //
//                                                           //
// Copyright (c) 2005 by TimTimTimma                         //
// http://TimTimTimma.com                        	     //
//                                                           //
// This program is free software; you can redistribute it    //
// and/or modify it under the terms of the GNU General Public//
// License as published by the Free Software Foundation;     //
// either version 2 of the License, or (at your option) any  //
// later version.                                            //
//                                                           //
// This program is distributed in the hope that it will be   //
// useful, but WITHOUT ANY WARRANTY; without even the implied//
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR   //
// PURPOSE.  See the GNU General Public License for more     //
// details.                                                  //
///////////////////////////////////////////////////////////////

///////////////////////////////
//   English Language File   //
///////////////////////////////

define("_U_ERROR", "<b>Error!</b>");
define("_NO_USER_ID", "You did not supply a valid user id.");
define("_WEBSITE", "Homepage");
define("_OCC", "Occupation");
define("_LOCATION", "Location");
define("_INTERESTS", "Interests");
define("_CONTACT_INFO", "Contact Information");
define("_EMAIL", "E-mail");
define("_GROUP", "Group");
define("_JOINED", "Joined");
define("_SEND_A_PM", "Send a private message to this user");
define("_NO_INFO", "<em>No information</em>");
define("_GENERAL_INFO", "General Information");
define("_OTHER_INFO", "Other Information");
define("_SIGNATURE", "Signature");
define("_POST", "Post Count");
define("_ADMIN", "Administrator");
define("_MOD", "Moderator");
define("_AP", "Article Publisher");
define("_MEMBER", "Member");
define("_DONT_DISPLAY_EMAIL", "This user wishes not to reveal his/her email at this time.");
define("_SELECT_A_USER", "Select a Username");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");


?>