<?php

define("_CONTENT_PAGE", "Contents Page");
define("_TITLE", "Title");
define("_DESCRIPTION", "Description");
define("_VIEWS", "Views");
define("_POSTED_ON", "Posted on");
define("_PAGE_DOESNT_EXIST", "The page you requested does NOT exist");
define("_NO_CONTENT", "There is currently no content.");
define("_ONLY_REGISTERED_USERS", "<strong>Only registered users may view this page.</strong>");
define("_ONLY_ADMINS", "<strong>Only site staff may view this page.</strong>");
define("_ONLY_MODERATORS", "<strong>Only site moderators may view this page.</strong>");
define("_ONLY_PUBLISHERS", "<strong>Only site article publishers may view this page.</strong>");
define("_ONLY_GROUP", "<strong>Only the group");
define("_MAY_VIEW", "may view this page</strong>");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
?>