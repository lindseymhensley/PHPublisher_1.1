<?php

define("_NO_DOWNLOADS", "We do not have any downloads available in this category currently.");
define("_TITLE", "Title");
define("_DESCRIPTION", "Description");
define("_NO_RESULTS", "Your search returned no results.");
define("_FILE_SIZE", "Filesize");
define("_ADDED_ON", "Added on");
define("_DOWNLOADS", "Downloads");
define("_HOMEPAGE", "Homepage");
define("_DOWNLOAD", "Download");
define("_DOWNLOAD_BY_CATEGORY", "Download by Category");
define("_AVAILABLE_DOWNLOADS", "Available Downloads");
define("_DOWNLOAD_PAGE", "Page");
define("_AUTHOR", "Submitted by");
define("_ADD_DL", "Add Download");
define("_DL_SUBMITTED", "Your download has been submitted, please allow 24/48 hours for review.");
define("_MISSING_ADD_DL_FIELDS", "There was an error in your form, please press back and try again.");
define("_URL", "Url");
define("_RANK", "#");
define("_GO_BACK", "Go Back");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");
define("", "");

?>