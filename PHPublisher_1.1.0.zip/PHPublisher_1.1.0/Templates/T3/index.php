<?php
header('location: http://t3-network.com/T3/index.php');
?>