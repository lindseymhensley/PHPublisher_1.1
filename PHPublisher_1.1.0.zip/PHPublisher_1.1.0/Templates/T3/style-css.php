<?php
header("Content-type: text/css");
?>
body {
	PADDING-RIGHT: 0px;
	PADDING-LEFT: 0px;
	MARGIN: 0px;
	PADDING-BOTTOM: 0px;
	PADDING-TOP: 0px;
	font-family: Verdana, sans-serif;
	font-size: 11px;
	font-style: normal;
	line-height: normal;
	font-weight: normal;
	font-variant: normal;
	text-transform: none;
	color: #707070;
	leftmargin:0;
	topmargin:0;
	marginwidth:0;
	marginheight:0;
}
.header {
	font-family: Verdana, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: normal;
	font-weight: bold;
	font-variant: normal;
	text-transform: none;
	color:#663366; 
	padding-left:5; 
	padding-right:5; 

}
a:link{
	font-family:Verdana,sans-serif; 
	font-size: 11px; 
	text-decoration: none; 
	color:#663366;
}
a:visited{
	font-family:Verdana,sans-serif; 
	font-size: 11px; 
	text-decoration: none; 
	color: #663366;
}
a:hover{
	font-family:Verdana,sans-serif; 
	font-size: 11px; 
	text-decoration: none; 
	color: #CC0099;
}
a:active{
	font-family: Verdana,sans-serif; 
	font-size: 11px; 
	text-decoration: none; 
	color: #663366;
}

td, textarea, input, select {
	font-family: Verdana, sans-serif;
	font-size: 11px;
	color: #707070;
	font-weight: normal;
}
.table
{
	border: 1px solid;
	border-color: #993399;
}