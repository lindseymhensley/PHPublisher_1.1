<?php
header("Content-type: text/css");
?>
<style type='text/css'>

FONT,BODY,P,DIV,TABLE	{	FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
							FONT-SIZE: 11px
						}
						
BODY	{	SCROLLBAR-FACE-COLOR: #286293; 
			SCROLLBAR-SHADOW-COLOR: #000000; 
			SCROLLBAR-HIGHLIGHT-COLOR: #215581;
			SCROLLBAR-3DLIGHT-COLOR: #000000; 
			SCROLLBAR-DARKSHADOW-COLOR: #215581; 
			SCROLLBAR-TRACK-COLOR: #215581; 
			SCROLLBAR-ARROW-COLOR: #000000; 			
			MARGIN-LEFT: 0px;
			MARGIN-RIGHT: 0px;
			MARGIN-TOP: 0px;
			MARGIN-BOTTOM: 0px;
			MARGIN-WIDTH: 0px;
			MARGIN-HEIGHT: 0px;
			background-color: #215581;
			FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
			FONT-SIZE:11px;
			COLOR:#FFFFFF; 
			Margin: 10px;
		}
		
TABLE,TR,TD	{	FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
				FONT-SIZE:11px; 
				PADDING-LEFT:0px; 
				PADDING-RIGHT:0px; 
			}
.table {border: 1px solid; border-color: #215581}

A:link	{	BACKGROUND: none; 
			COLOR: #ffffff; 
			FONT-SIZE: 11px Arial, Helvetica, Verdana, sans-serif; 
			TEXT-DECORATION: none
		}

A:active	{	BACKGROUND: none; 
				COLOR: #ffffff; 
				FONT-SIZE: 10px Arial, Helvetica, Verdana, sans-serif; 
				TEXT-DECORATION: none
			}

A:visited	{	BACKGROUND: none; 
				COLOR: #ffffff; 
				FONT-SIZE: 11px Arial, Helvetica, Verdana, sans-serif; 
				TEXT-DECORATION: none
			}

A:hover		{	BACKGROUND: none; 
				COLOR: #ffffff; 
				FONT-SIZE: 11px Arial, Helvetica, Verdana, sans-serif; 
				TEXT-DECORATION: underline
			}
			
INPUT		{	FONT-SIZE: 11px; 
				FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
				COLOR: #FFFFFF; 
				BACKGROUND-COLOR : #215581; 
				BORDER: #000000; 
				BORDER-STYLE: solid; 
				BORDER-TOP-WIDTH : 1px; 
				BORDER-RIGHT-WIDTH : 1px; 
				BORDER-BOTTOM-WIDTH : 1px; 
				BORDER-LEFT-WIDTH : 1px
			}

INPUT.BUTTON	{	BORDER-TOP-WIDTH : 1px; 
					BORDER-RIGHT-WIDTH : 1px; 
					BORDER-BOTTOM-WIDTH : 1px; 
					BORDER-LEFT-WIDTH : 1px
				}

TEXTAREA		{	FONT-SIZE: 11px; 
					FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
					COLOR: #FFFFFF; 
					BACKGROUND-COLOR : #215581; 
					BORDER: #000000; 
					BORDER-STYLE: solid; 
					BORDER-TOP-WIDTH : 1px; 
					BORDER-RIGHT-WIDTH : 1px; 
					BORDER-BOTTOM-WIDTH : 1px; 
					BORDER-LEFT-WIDTH : 1px
				}

SELECT 			{	FONT-SIZE: 11px;
					BACKGROUND-COLOR : #215581;
					COLOR : #FFFFFF; 
					FONT-FAMILY: Verdana, Geneva, Arial, Helvetica; 
					BORDER: #000000; 
					BORDER-STYLE: solid; 
					BORDER-TOP-WIDTH : 1px; 
					BORDER-RIGHT-WIDTH : 1px; 
					BORDER-BOTTOM-WIDTH : 1px; 
					BORDER-LEFT-WIDTH : 1px
				}
.tiny		{BACKGROUND: none; FONT-SIZE: 9px; FONT-WEIGHT: normal; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}

 </style>