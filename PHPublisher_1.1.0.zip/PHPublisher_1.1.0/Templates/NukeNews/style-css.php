<?php
header("Content-type: text/css");
?>
FONT		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
TD		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
BODY		{FONT-FAMILY: Verdana,Helvetica; COLOR: #000000; BACKGROUND-COLOR: #505050; FONT-SIZE: 11px}
P		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
DIV		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
INPUT		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
TEXTAREA	{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
FORM 		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px}
A:link          {BACKGROUND: none; COLOR: #363636; FONT-SIZE: 11px; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: underline}
A:active        {BACKGROUND: none; COLOR: #d5ae83; FONT-SIZE: 11px; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: underline}
A:visited       {BACKGROUND: none; COLOR: #363636; FONT-SIZE: 11px; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: underline}
A:hover         {BACKGROUND: none; COLOR: #d5ae83; FONT-SIZE: 11px; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: underline}
.title 		{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 13px; FONT-WEIGHT: bold; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}
.content 	{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 11px; FONT-FAMILY: Verdana, Helvetica}
.storytitle 	{BACKGROUND: none; COLOR: #363636; FONT-SIZE: 14px; FONT-WEIGHT: bold; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}
.storycat	{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 13px; FONT-WEIGHT: bold; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: underline}
.boxtitle 	{BACKGROUND: none; COLOR: #363636; FONT-SIZE: 11px; FONT-WEIGHT: bold; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}
.boxcontent 	{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 12px; FONT-FAMILY: Verdana, Helvetica}
.option 	{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 13px; FONT-WEIGHT: bold; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}
.tiny		{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 10px; FONT-WEIGHT: normal; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}
.footmsg        {BACKGROUND: none; COLOR: #000000; FONT-SIZE: 8px; FONT-WEIGHT: normal; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: none}
.footmsg_l	{BACKGROUND: none; COLOR: #000000; FONT-SIZE: 8px; FONT-WEIGHT: normal; FONT-FAMILY: Verdana, Helvetica; TEXT-DECORATION: underline}
.box		{FONT-FAMILY: Verdana,Helvetica; FONT-SIZE: 11px; border: 1px solid #000000; background-color: #FFFFFF}
.table {border: 1px solid; border-color:#363636}