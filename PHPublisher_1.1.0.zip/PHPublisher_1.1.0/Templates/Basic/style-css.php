<?php
header("Content-type: text/css");
?>
<style type='text/css'>

FONT,BODY,P,DIV,TABLE	{	FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
							FONT-SIZE: 10px
						}

BODY	{	SCROLLBAR-FACE-COLOR: #0F414B; 
			SCROLLBAR-SHADOW-COLOR: #3398A7; 
			SCROLLBAR-HIGHLIGHT-COLOR: #3398A7;
			SCROLLBAR-3DLIGHT-COLOR: #0F414B; 
			SCROLLBAR-DARKSHADOW-COLOR: #0F414B; 
			SCROLLBAR-TRACK-COLOR: #0F414B; 
			SCROLLBAR-ARROW-COLOR: #3398A7; 
			MARGIN-LEFT: 0px;
			MARGIN-RIGHT: 0px;
			MARGIN-TOP: 0px;
			MARGIN-BOTTOM: 0px;
			MARGIN-WIDTH: 0px;
			MARGIN-HEIGHT: 0px;
			FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
			FONT-SIZE:10px;
			BACKGROUND-COLOR: #0F414B;
			COLOR:#FFFFFF; 
		}

TABLE,TR,TD	{	FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
				FONT-SIZE:10px; 
				BORDER-COLOR:#3398A7; 
				PADDING-LEFT:0px; 
				PADDING-RIGHT:0px; 
			}
A:link	{	BACKGROUND: none; 
			COLOR: #3398A7; 
			FONT-SIZE: 10px Arial, Helvetica, Verdana, sans-serif; 
			TEXT-DECORATION: none
		}

A:active	{	BACKGROUND: none; 
				COLOR: #3398A7; 
				FONT-SIZE: 10px Arial, Helvetica, Verdana, sans-serif; 
				TEXT-DECORATION: none
			}

A:visited	{	BACKGROUND: none; 
				COLOR: #3398A7; 
				FONT-SIZE: 10px Arial, Helvetica, Verdana, sans-serif; 
				TEXT-DECORATION: none
			}

A:hover		{	BACKGROUND: none; 
				COLOR: #79CDD9; 
				FONT-SIZE: 10px Arial, Helvetica, Verdana, sans-serif; 
				TEXT-DECORATION: none
			}

INPUT		{	FONT-SIZE: 10px; 
				FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
				COLOR: #FFFFFF; 
				BACKGROUND-COLOR : #0F414B; 
				BORDER: #3398A7; 
				BORDER-STYLE: solid; 
				BORDER-TOP-WIDTH : 1px; 
				BORDER-RIGHT-WIDTH : 1px; 
				BORDER-BOTTOM-WIDTH : 1px; 
				BORDER-LEFT-WIDTH : 1px
			}

INPUT.BUTTON	{	BORDER-TOP-WIDTH : 1px; 
					BORDER-RIGHT-WIDTH : 1px; 
					BORDER-BOTTOM-WIDTH : 1px; 
					BORDER-LEFT-WIDTH : 1px
				}

TEXTAREA		{	FONT-SIZE: 10px; 
					FONT-FAMILY: Arial, Helvetica, Verdana, sans-serif; 
					COLOR: #FFFFFF; 
					BACKGROUND-COLOR : #0F414B; 
					BORDER: #3398A7; 
					BORDER-STYLE: solid; 
					BORDER-TOP-WIDTH : 1px; 
					BORDER-RIGHT-WIDTH : 1px; 
					BORDER-BOTTOM-WIDTH : 1px; 
					BORDER-LEFT-WIDTH : 1px
				}

SELECT 			{	FONT-SIZE: 10px;
					BACKGROUND-COLOR : #0F414B;
					COLOR : #FFFFFF; 
					FONT-FAMILY: Verdana, Geneva, Arial, Helvetica; 
					BORDER: #3398A7; 
					BORDER-STYLE: solid; 
					BORDER-TOP-WIDTH : 1px; 
					BORDER-RIGHT-WIDTH : 1px; 
					BORDER-BOTTOM-WIDTH : 1px; 
					BORDER-LEFT-WIDTH : 1px
				}
.table {border: 1px solid; border-color: #33A3AA }
</style>