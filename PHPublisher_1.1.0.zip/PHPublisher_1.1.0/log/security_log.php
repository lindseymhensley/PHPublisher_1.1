<?php

if(!defined("IN_DB")){
	die("Hacking Attempt!");
}

?>
	